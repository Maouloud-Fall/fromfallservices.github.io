# PHP Crash Course 2020

## Final version - *All code written during the video is there*

If you are interested to see empty files to following the tutorial switch to `master` branch. 

The video covers all the basic things about PHP. 

 - Comments
 - Variables
 - Numbers
 - Strings
 - Arrays
 - Conditionals
 - Loops
 - Functions
 - Dates
 - Including PHP files
 - Working with File System
 - Object Oriented PHP (OOP)
 - CURL
 - Product CRUD
    - Working with forms
    - File uploading and file validation
    - Working with mysql
 - Composer and autoloading
