<h1>Update product</h1>

<?php include "_form.php"; ?>