<?php

namespace app;

class Person
{
    public function __construct()
    {
        echo "Person class";
    }
}