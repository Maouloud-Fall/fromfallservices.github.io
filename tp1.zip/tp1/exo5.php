<!DOCTYPE html>
<html>
<head>
    <title>Exercice 5</title>
</head>
<body>
    <?php
        $site = "tutoriels";

        echo "Je suis le site : " . $site . "<br>";

        if ($site == "tutoriels") {
            echo "La variable 'site' contient 'tutoriels'.";
        } else {
            echo "La variable 'site' ne contient pas 'tutoriels'.";
        }
    ?>
</body>
</html>
