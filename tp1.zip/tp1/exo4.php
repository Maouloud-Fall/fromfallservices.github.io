<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercice 4</title>
</head>
<body>
    <?php
        $heure = 19;

        if ($heure >= 6 && $heure < 12) {
            echo "C'est le matin.";
        } elseif ($heure >= 12 && $heure < 18) {
            echo "C'est l'après-midi.";
        } else {
            echo "C'est la nuit.";
        }
    ?>

</body>
</html>