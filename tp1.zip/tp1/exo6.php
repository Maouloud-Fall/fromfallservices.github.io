<!DOCTYPE html>
<html>
<head>
    <title>Exercice 6</title>
</head>
<body>
    <?php
        $moyenne = 15; // Remplacez cette valeur par la moyenne de l'élève
        $decision = "";
        $mention = "";

        echo "Moyenne : " . $moyenne . "<br>";

        if ($moyenne >= 10) {
            $decision = "Admis";

            if ($moyenne >= 17) {
                $mention = "Excellent";
            } elseif ($moyenne >= 16) {
                $mention = "Très Bien";
            } elseif ($moyenne >= 14) {
                $mention = "Bien";
            } elseif ($moyenne >= 12) {
                $mention = "Assez Bien";
            } else {
                $mention = "Passable";
            }
        } else {
            $decision = "Éliminé";
        }

        echo "Décision : " . $decision . "<br>";
        echo "Mention : " . $mention;
    ?>
</body>
</html>
