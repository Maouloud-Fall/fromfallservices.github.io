<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercice 1</title>
</head>
<body>
    <?php
        $sexe = "femme";

        if ($sexe == "homme") {
            echo "Bienvenue Monsieur !";
        } elseif ($sexe == "femme") {
            echo "Bienvenue Madame !";
        } else {
            echo "Sexe inconnu.";
        }
    ?>

</body>
</html>