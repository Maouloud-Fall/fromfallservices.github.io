<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

function randomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str = '';
    for ($i = 0; $i < $length; $i++) {
        $str .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $str;
}

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_GET['id'] ?? null;
    if (!$id) {
        header('Location: index.php');
        exit;
    }

    $pdo = new PDO('mysql:host=localhost;port=8013;dbname=products_crud', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];
    $numero = !empty($_POST['numero']) ? $_POST['numero'] : null;

    $image = $_FILES['image'] ?? null;

    // Fetch the existing data for pre-filling the form
    $stmt = $pdo->prepare('SELECT * FROM voyages WHERE id = :id');
    $stmt->bindValue(':id', $id);
    $stmt->execute();
    $voyages = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the image is not updated
    if (!$image['name']) {
        // Use the existing image path
        $imagePath = $voyages['image'];
    } else {
        // Update the image
        $imagePath = 'images/' . randomString(8) . '/' . $image['name'];
        mkdir(dirname($imagePath));
        move_uploaded_file($image['tmp_name'], $imagePath);
    }

    // Signal error
    if (!$prenom) {
        $errors[] = 'Your firstname is required';
    }
    if (!$nom) {
        $errors[] = 'Your name is required';
    }

    // Additional validations can be added here for prenom and nom fields

    if (empty($errors)) {
        // UPDATE Query instead of INSERT
        $stmt = $pdo->prepare("UPDATE voyages SET prenom = :prenom, nom = :nom, numero = :numero, image = :image WHERE id = :id");

        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':prenom', $prenom);
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':numero', $numero, PDO::PARAM_INT);
        $stmt->bindParam(':image', $imagePath);

        // Execute the statement
        if ($stmt->execute()) {
            // Data updated successfully
            header('Location: index.php');
            exit;
        } else {
            // Handle error if needed
            $errors[] = 'Error updating data';
        }
    }
}

// Fetch the existing data for pre-filling the form
$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: index.php');
    exit;
}

$pdo = new PDO('mysql:host=localhost;port=8013;dbname=products_crud', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $pdo->prepare('SELECT * FROM voyages WHERE id = :id');
$stmt->bindValue(':id', $id);
$stmt->execute();
$voyages = $stmt->fetch(PDO::FETCH_ASSOC);

// Set initial values for the form fields
$prenom = $voyages['prenom'];
$nom = $voyages['nom'];
$numero = $voyages['numero'];
?>

<!-- Rest of the HTML code remains unchanged -->


<!-- Rest of the HTML code remains unchanged -->

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Formulaire d'Identifiant</title>
</head>

<body>

    <p>
        <a href="index.php" class="btn btn-secondary">Go back Home</a>
    </p>

    <h1>New Identified</h1>
    <?php if (!empty($errors)) : ?>
    <div class="alert alert-danger">
        <?php foreach ($errors as $error) : ?>
        <div><?php echo $error ?></div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <form action="update.php?id=<?php echo $id; ?>" method="post" enctype="multipart/form-data">

        <?php if ($voyages['image']): ?>
            <img src="<?php echo $voyages['image'] ?>" class="update-image">
        <?php endif; ?>

        <div class="mb-3">
            <label>Your Image</label><br>
            <input type="file" name="image" accept="image/*">

        </div>
        <div class="mb-3">
            <label>Your Prenoun</label>
            <input type="text" class="form-control" name="prenom" placeholder="Votre prenom" required value="<?php echo $prenom; ?>">
        </div>
        <div class="mb-3">
            <label>Your Noun</label>
            <input type="text" class="form-control" name="nom" placeholder="Votre nom" required value="<?php echo $nom; ?>">
        </div>
        <div class="mb-3">
            <label>Your Number</label>
            <input type="number" class="form-control" name="numero" placeholder="Votre numero" required value="<?php echo $numero; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</body>

</html>
