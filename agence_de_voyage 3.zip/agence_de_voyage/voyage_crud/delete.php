<?php
$pdo = new PDO('mysql:host=localhost;port=8013;dbname=products_crud', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 

$id = $_POST['id'] ?? null;
if (!$id){
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare('DELETE FROM voyages WHERE id = :id');
$stmt->bindValue(':id', $id); // Fix the bindValue() function call
$stmt->execute();

header('Location: index.php');
?>
