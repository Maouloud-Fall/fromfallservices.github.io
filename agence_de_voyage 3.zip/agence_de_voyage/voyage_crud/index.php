<?php
$pdo = new PDO('mysql:host=localhost;port=8013;dbname=products_crud', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Check if a search query is provided
$search = $_GET['search'] ?? '';

// Update the SQL query to filter results based on the search query
if (!empty($search)) {
    $statement = $pdo->prepare('SELECT * FROM voyages WHERE prenom LIKE :search OR nom LIKE :search OR numero = :search ORDER BY numero DESC');
    $statement->bindValue(':search', '%' . $search . '%');
} else {
    $statement = $pdo->prepare('SELECT * FROM voyages ORDER BY numero DESC');
}

$statement->execute();
$voyages = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Rest of the HTML code remains unchanged -->


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <style>
        .thumb-image {
            width: 50px; /* Set the desired width (e.g., 50px) */
            height: 50px; /* Set the desired height (e.g., 50px) */
            object-fit: cover; /* Optional: Maintain aspect ratio and crop if necessary */
        }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Formulaire d'Idenfiant</title>
  </head>
  <body>
    <h1><marquee behavior="alternate" direction="">Formulaire des Idenfiants</marquee> </h1>
    <p>
        <a href="create.php" class="btn btn-success">Identified</a>
    </p>
    <form action="index.php" method="GET">
        <div class="input-group mb-3">
            <input type="text" class="form-control" name="search" placeholder="Search by name or number">
            <div class="input-group-append">
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
        </div>
    </form>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Image</th>
                <th scope="col">Prenom</th>
                <th scope="col">Nom</th>
                <th scope="col">Numero</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($voyages as $i => $voyages): ?>
            <tr>
                <th scope="row"><?php echo $i + 1 ?></th>
                <td>
                    <img src="<?php echo $voyages['image'] ?>" class="thumb-image">
                </td>

                <td><?php echo $voyages['prenom'] ?></td>
                <td><?php echo $voyages['nom'] ?></td>
                <td><?php echo $voyages['numero'] ?></td>
                <td>
                    <a href="update.php?id=<?php echo $voyages['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                    <form style="display: inline-block;" method="POST" action="delete.php">
                        <input type="hidden" name="id" value="<?php echo $voyages['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>

        </tbody>
    </table>
    
  </body>
</html>